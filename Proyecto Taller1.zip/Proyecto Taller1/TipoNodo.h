#ifndef TIPONODO_H_INCLUDED
#define TIPONODO_H_INCLUDED
#include "Boolean.h"


typedef enum {VALOR, OPERADOR, PARENTESIS} TipoNodo;



#endif // TIPONODO_H_INCLUDED
