#include "TipoNodo.h"

//Cargar tipo de nodo
void CargarNodo (TipoNodo &Nodo);

//Mostrar tipo de nodo
void MostrarNodo (TipoNodo Nodo);

//Devolver tipo nodo
TipoNodo DevolverNodo (TipoNodo Nodo){
  return Nodo;
}


